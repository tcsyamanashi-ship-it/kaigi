/**
 * ファイルアップロード・処理クラス
 * PDF, Word, テキストファイルからのテキスト抽出機能
 */

class FileHandler {
    constructor() {
        this.acceptedTypes = [
            'application/pdf',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'text/plain',
            'text/csv'
        ];
        this.maxFileSize = 10 * 1024 * 1024; // 10MB
        this.init();
    }

    init() {
        this.bindEvents();
    }

    bindEvents() {
        const uploadZone = document.getElementById('uploadZone');
        const fileInput = document.getElementById('fileInput');
        const analyzeBtn = document.getElementById('analyzeBtn');

        // ドラッグ&ドロップ
        uploadZone?.addEventListener('click', () => fileInput?.click());
        uploadZone?.addEventListener('dragover', this.handleDragOver.bind(this));
        uploadZone?.addEventListener('dragleave', this.handleDragLeave.bind(this));
        uploadZone?.addEventListener('drop', this.handleDrop.bind(this));

        // ファイル選択
        fileInput?.addEventListener('change', this.handleFileSelect.bind(this));

        // 解析ボタン
        analyzeBtn?.addEventListener('click', this.analyzeFile.bind(this));
    }

    handleDragOver(e) {
        e.preventDefault();
        e.stopPropagation();
        e.currentTarget.classList.add('dragover');
    }

    handleDragLeave(e) {
        e.preventDefault();
        e.stopPropagation();
        e.currentTarget.classList.remove('dragover');
    }

    handleDrop(e) {
        e.preventDefault();
        e.stopPropagation();
        e.currentTarget.classList.remove('dragover');

        const files = e.dataTransfer.files;
        if (files.length > 0) {
            this.processFile(files[0]);
        }
    }

    handleFileSelect(e) {
        const files = e.target.files;
        if (files.length > 0) {
            this.processFile(files[0]);
        }
    }

    async processFile(file) {
        // ファイル検証
        if (!this.validateFile(file)) {
            return;
        }

        try {
            // ファイル情報を表示
            this.showFileInfo(file);
            
            // テキスト抽出
            const extractedText = await this.extractText(file);
            
            if (extractedText) {
                // グローバル変数に保存（AI解析で使用）
                window.extractedText = extractedText;
                window.currentFileName = file.name;
                
                // 解析ボタンを有効化
                document.getElementById('analyzeBtn').disabled = false;
                
                // プレビューエリアにテキストの一部を表示
                this.showTextPreview(extractedText);
                
                console.log('テキスト抽出完了:', extractedText.length, '文字');
            } else {
                throw new Error('テキストの抽出に失敗しました');
            }

        } catch (error) {
            console.error('ファイル処理エラー:', error);
            alert('ファイルの処理中にエラーが発生しました: ' + error.message);
            this.resetUploadState();
        }
    }

    validateFile(file) {
        // ファイルタイプ検証
        if (!this.acceptedTypes.includes(file.type)) {
            alert('サポートされていないファイル形式です。\\nPDF、Word文書、テキストファイルをアップロードしてください。');
            return false;
        }

        // ファイルサイズ検証
        if (file.size > this.maxFileSize) {
            alert('ファイルサイズが大きすぎます。10MB以下のファイルをアップロードしてください。');
            return false;
        }

        return true;
    }

    async extractText(file) {
        const fileType = file.type;
        
        try {
            if (fileType === 'text/plain' || fileType === 'text/csv') {
                return await this.extractTextFromPlainText(file);
            } else if (fileType === 'application/pdf') {
                return await this.extractTextFromPDF(file);
            } else if (fileType.includes('word') || fileType.includes('officedocument')) {
                return await this.extractTextFromWord(file);
            } else {
                throw new Error('サポートされていないファイル形式');
            }
        } catch (error) {
            console.error('テキスト抽出エラー:', error);
            throw error;
        }
    }

    async extractTextFromPlainText(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => resolve(e.target.result);
            reader.onerror = () => reject(new Error('テキストファイルの読み込みに失敗しました'));
            reader.readAsText(file, 'UTF-8');
        });
    }

    async extractTextFromPDF(file) {
        // PDF.jsを使用（CDNから読み込み）
        if (typeof pdfjsLib === 'undefined') {
            // PDF.jsが利用できない場合の代替処理
            console.warn('PDF.js not available, using alternative method');
            return await this.extractTextAlternative(file);
        }

        try {
            const arrayBuffer = await file.arrayBuffer();
            const pdf = await pdfjsLib.getDocument(arrayBuffer).promise;
            let fullText = '';

            for (let i = 1; i <= pdf.numPages; i++) {
                const page = await pdf.getPage(i);
                const textContent = await page.getTextContent();
                const pageText = textContent.items.map(item => item.str).join(' ');
                fullText += pageText + '\\n\\n';
            }

            return fullText.trim();
        } catch (error) {
            console.error('PDF処理エラー:', error);
            return await this.extractTextAlternative(file);
        }
    }

    async extractTextFromWord(file) {
        // mammoth.jsやdocx.jsを使用（CDNから読み込み）
        try {
            if (typeof mammoth !== 'undefined') {
                const arrayBuffer = await file.arrayBuffer();
                const result = await mammoth.extractRawText({arrayBuffer});
                return result.value;
            } else {
                // 代替方法
                return await this.extractTextAlternative(file);
            }
        } catch (error) {
            console.error('Word処理エラー:', error);
            return await this.extractTextAlternative(file);
        }
    }

    async extractTextAlternative(file) {
        // 基本的なテキスト抽出（FileReader使用）
        // 実際の業務では、サーバーサイドでの処理が推奨されます
        console.log('代替テキスト抽出方法を使用');
        
        return new Promise((resolve) => {
            const reader = new FileReader();
            reader.onload = (e) => {
                const text = e.target.result;
                // 簡易的なテキスト抽出（実際のPDFやWordでは限定的）
                const cleanText = text.replace(/[^\\x20-\\x7E\\u3040-\\u309F\\u30A0-\\u30FF\\u4E00-\\u9FAF\\u002D\\u002E\\u0030-\\u0039]/g, '')
                    .replace(/\\s+/g, ' ')
                    .trim();
                
                if (cleanText.length > 100) {
                    resolve(cleanText);
                } else {
                    resolve('ファイルからテキストを抽出しましたが、内容が不完全な可能性があります。\\n手動でテキストを入力してください。\\n\\n[抽出されたテキスト]\\n' + cleanText);
                }
            };
            reader.readAsText(file, 'UTF-8');
        });
    }

    showFileInfo(file) {
        const uploadZone = document.getElementById('uploadZone');
        const fileSize = (file.size / 1024 / 1024).toFixed(2);
        
        uploadZone.innerHTML = `
            <div class="text-center">
                <i class="fas fa-file-check text-4xl text-green-600 mb-4"></i>
                <p class="text-lg font-medium text-gray-700 mb-2">ファイル選択完了</p>
                <p class="text-sm text-gray-600 mb-2">
                    <strong>${file.name}</strong>
                </p>
                <p class="text-xs text-gray-500 mb-4">
                    サイズ: ${fileSize} MB | 形式: ${this.getFileTypeLabel(file.type)}
                </p>
                <div class="flex items-center justify-center space-x-2 text-blue-600">
                    <div class="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
                    <span class="text-sm">テキストを抽出しています...</span>
                </div>
            </div>
        `;
    }

    showTextPreview(text) {
        const uploadZone = document.getElementById('uploadZone');
        const previewText = text.length > 200 ? text.substring(0, 200) + '...' : text;
        
        uploadZone.innerHTML = `
            <div class="text-center">
                <i class="fas fa-file-check text-4xl text-green-600 mb-4"></i>
                <p class="text-lg font-medium text-gray-700 mb-2">テキスト抽出完了</p>
                <p class="text-sm text-gray-600 mb-4">
                    ${text.length} 文字のテキストが抽出されました
                </p>
                <div class="bg-gray-100 p-3 rounded-md text-xs text-left text-gray-700 mb-4 max-h-24 overflow-y-auto">
                    ${previewText.replace(/\\n/g, '<br>')}
                </div>
                <p class="text-sm text-blue-600 font-medium">
                    <i class="fas fa-arrow-down mr-2"></i>AI解析ボタンをクリックして構造化を開始
                </p>
            </div>
        `;
    }

    getFileTypeLabel(mimeType) {
        const typeLabels = {
            'application/pdf': 'PDF',
            'application/msword': 'Word (旧形式)',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'Word',
            'text/plain': 'テキスト',
            'text/csv': 'CSV'
        };
        return typeLabels[mimeType] || '不明';
    }

    resetUploadState() {
        const uploadZone = document.getElementById('uploadZone');
        const analyzeBtn = document.getElementById('analyzeBtn');
        
        uploadZone.innerHTML = `
            <i class="fas fa-cloud-upload-alt text-4xl text-gray-400 mb-4"></i>
            <p class="text-lg font-medium text-gray-700 mb-2">ファイルをドラッグ＆ドロップ</p>
            <p class="text-sm text-gray-500 mb-4">または <span class="text-blue-600 font-medium cursor-pointer">ここをクリック</span> してファイルを選択</p>
            <p class="text-xs text-gray-400">対応形式: PDF, Word(.doc/.docx), テキスト(.txt)</p>
        `;
        
        analyzeBtn.disabled = true;
        window.extractedText = '';
        window.currentFileName = '';
        
        // ファイル入力をリセット
        const fileInput = document.getElementById('fileInput');
        if (fileInput) fileInput.value = '';
    }

    async analyzeFile() {
        if (!window.extractedText) {
            alert('解析するテキストがありません。ファイルをアップロードしてください。');
            return;
        }

        const analyzeBtn = document.getElementById('analyzeBtn');
        const originalText = analyzeBtn.innerHTML;
        
        try {
            // ボタン状態を更新
            analyzeBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>AI解析中...';
            analyzeBtn.disabled = true;

            // AI解析を実行
            if (window.AIAnalyzer) {
                await window.AIAnalyzer.analyzeText(window.extractedText);
            } else {
                // AIAnalyzerが読み込まれていない場合のフォールバック
                this.performBasicAnalysis(window.extractedText);
            }

        } catch (error) {
            console.error('解析エラー:', error);
            alert('AI解析中にエラーが発生しました: ' + error.message);
        } finally {
            // ボタンを元に戻す
            analyzeBtn.innerHTML = originalText;
            analyzeBtn.disabled = false;
        }
    }

    performBasicAnalysis(text) {
        // 基本的な解析（キーワードベース）
        console.log('基本解析を実行');
        
        const analysis = {
            issues: this.extractByKeywords(text, ['課題', '問題', '改善', 'リスク', '懸念']),
            decisions: this.extractByKeywords(text, ['決定', '承認', '可決', '合意', '決議']),
            tasks: this.extractByKeywords(text, ['タスク', 'アクション', '宿題', '対応', '実施']),
            discussion: this.extractByKeywords(text, ['議論', '検討', '意見', '提案', '質問']),
            nextSteps: this.extractByKeywords(text, ['次回', '今後', '次の', 'フォロー', '継続'])
        };

        this.displayAnalysisResults(analysis);
    }

    extractByKeywords(text, keywords) {
        const sentences = text.split(/[。\\n]/);
        const matched = [];
        
        keywords.forEach(keyword => {
            sentences.forEach(sentence => {
                if (sentence.includes(keyword) && sentence.trim()) {
                    matched.push(sentence.trim());
                }
            });
        });
        
        return matched.slice(0, 5); // 最大5項目
    }

    displayAnalysisResults(analysis) {
        // 結果をUIに反映
        document.getElementById('issuesContent').innerHTML = 
            analysis.issues.length ? analysis.issues.map(item => `• ${item}`).join('<br>') : '課題は特定されませんでした';
        
        document.getElementById('decisionsContent').innerHTML = 
            analysis.decisions.length ? analysis.decisions.map(item => `• ${item}`).join('<br>') : '決定事項は特定されませんでした';
        
        document.getElementById('tasksContent').innerHTML = 
            analysis.tasks.length ? analysis.tasks.map(item => `• ${item}`).join('<br>') : 'アクションアイテムは特定されませんでした';
        
        document.getElementById('discussionContent').innerHTML = 
            analysis.discussion.length ? analysis.discussion.map(item => `• ${item}`).join('<br>') : '主な議論点は特定されませんでした';
        
        document.getElementById('nextStepsContent').innerHTML = 
            analysis.nextSteps.length ? analysis.nextSteps.map(item => `• ${item}`).join('<br>') : '次のステップは特定されませんでした';

        // 結果エリアを表示
        document.getElementById('analysisResults')?.classList.remove('hidden');
        document.getElementById('analysisPlaceholder')?.classList.add('hidden');
    }
}

// 初期化
document.addEventListener('DOMContentLoaded', () => {
    window.FileHandler = new FileHandler();
    console.log('ファイルハンドラー初期化完了');
});