/**
 * AI解析エンジン - 議事録自動構造化システム
 * 介護事業特化型の議事録解析・分類機能
 */

class AIAnalyzer {
    constructor() {
        // 介護事業に特化したキーワードパターン
        this.careKeywords = {
            issues: [
                '課題', '問題', '困難', 'リスク', '懸念', '改善', '対策',
                'スタッフ不足', '人手不足', '離職', '残業', '業務負荷',
                '利用者様', 'ご家族', '苦情', 'クレーム', '事故', 'ヒヤリハット',
                '収支', '赤字', '売上', 'コスト', '経費', '効率化',
                '法令', 'コンプライアンス', '監査', '指導', '処遇改善'
            ],
            decisions: [
                '決定', '決議', '承認', '可決', '採用', '導入', '実施',
                '新規', '開始', '変更', '修正', '改訂', '更新',
                '予算', '投資', '購入', '契約', '締結', '合意',
                '人事', '採用', '異動', '昇進', '給与', '賞与',
                'サービス', 'プラン', 'メニュー', '料金', '価格'
            ],
            tasks: [
                'アクション', 'タスク', '宿題', '対応', '実施', '検討',
                '作成', '準備', '手配', '調整', '連絡', '報告',
                '研修', '教育', '指導', 'トレーニング', '学習',
                '改善', '見直し', '点検', 'チェック', '確認',
                '申請', '手続き', '提出', '届出', '更新'
            ],
            discussion: [
                '議論', '検討', '話し合い', '相談', '意見', '提案',
                '質問', '疑問', '確認', '説明', '報告', '共有',
                '課題', '問題', '改善案', 'アイデア', '工夫',
                '方針', '戦略', '計画', 'スケジュール', '予定'
            ],
            nextSteps: [
                '次回', '今後', '将来', 'フォローアップ', '継続',
                'スケジュール', '予定', '計画', '目標', '方向性',
                '検討', '調査', '研究', '準備', '段取り'
            ]
        };

        // 介護事業の部門・職種キーワード
        this.departmentKeywords = {
            '訪問介護': ['訪問', 'ヘルパー', '在宅', 'サービス提供責任者', '生活援助', '身体介護'],
            '有料老人ホーム': ['施設', '入居者', 'ケアマネ', '介護計画', '夜勤', 'フロア'],
            '介護タクシー': ['送迎', '通院', '外出', '車両', 'ドライバー', '移送'],
            '保険外サービス': ['自費', '保険外', '付加', 'オプション', '独自', 'サービス'],
            '経営企画': ['売上', '利益', '戦略', '計画', '分析', 'KPI', '改善']
        };

        // 重要度判定キーワード
        this.priorityKeywords = {
            '高': ['緊急', '至急', '重要', 'クリティカル', '事故', '法的', '監査', '赤字'],
            '中': ['改善', '検討', '課題', '対応', '計画', '準備'],
            '低': ['情報', '共有', '参考', '報告', 'FYI', '連絡']
        };

        this.init();
    }

    init() {
        console.log('AI解析エンジン初期化完了');
    }

    /**
     * メイン解析処理
     * @param {string} text - 解析対象テキスト
     */
    async analyzeText(text) {
        console.log('AI解析開始:', text.length, '文字');
        
        try {
            // テキストの前処理
            const cleanText = this.preprocessText(text);
            
            // 文章分割
            const sentences = this.splitIntoSentences(cleanText);
            console.log('文章分割完了:', sentences.length, '文');

            // 各カテゴリーに分類
            const analysis = {
                issues: this.categorizeByType(sentences, 'issues'),
                decisions: this.categorizeByType(sentences, 'decisions'),
                tasks: this.categorizeByType(sentences, 'tasks'),
                discussion: this.categorizeByType(sentences, 'discussion'),
                nextSteps: this.categorizeByType(sentences, 'nextSteps')
            };

            // 重要度を判定
            const priority = this.determinePriority(cleanText);
            
            // 部門を推定
            const department = this.estimateDepartment(cleanText);

            // 結果を表示
            this.displayResults(analysis, priority, department);
            
            console.log('AI解析完了', analysis);
            
        } catch (error) {
            console.error('AI解析エラー:', error);
            throw new Error('AI解析処理中にエラーが発生しました');
        }
    }

    /**
     * テキスト前処理
     */
    preprocessText(text) {
        return text
            .replace(/\\r\\n|\\r|\\n/g, '。') // 改行を句点に変換
            .replace(/\\s+/g, ' ') // 複数のスペースを単一に
            .replace(/[（）()\\[\\]【】]/g, '') // 括弧を削除
            .trim();
    }

    /**
     * 文章分割
     */
    splitIntoSentences(text) {
        return text
            .split(/[。．\\n]/)
            .filter(sentence => sentence.trim().length > 10) // 短すぎる文を除外
            .map(sentence => sentence.trim());
    }

    /**
     * カテゴリー別分類
     */
    categorizeByType(sentences, type) {
        const keywords = this.careKeywords[type] || [];
        const categorized = [];

        sentences.forEach(sentence => {
            let score = 0;
            let matchedKeywords = [];

            // キーワードマッチング
            keywords.forEach(keyword => {
                if (sentence.includes(keyword)) {
                    score += 1;
                    matchedKeywords.push(keyword);
                }
            });

            // スコアが閾値を超えた場合に分類
            if (score > 0) {
                categorized.push({
                    text: sentence,
                    score: score,
                    keywords: matchedKeywords,
                    priority: this.calculateSentencePriority(sentence)
                });
            }
        });

        // スコア順にソートして上位を返す
        return categorized
            .sort((a, b) => b.score - a.score)
            .slice(0, 8) // 最大8項目
            .map(item => item.text);
    }

    /**
     * 重要度判定
     */
    determinePriority(text) {
        let highScore = 0;
        let mediumScore = 0;
        let lowScore = 0;

        // 各重要度のキーワードをカウント
        this.priorityKeywords['高'].forEach(keyword => {
            if (text.includes(keyword)) highScore += 2;
        });

        this.priorityKeywords['中'].forEach(keyword => {
            if (text.includes(keyword)) mediumScore += 1;
        });

        this.priorityKeywords['低'].forEach(keyword => {
            if (text.includes(keyword)) lowScore += 0.5;
        });

        // 最高スコアの重要度を返す
        if (highScore > mediumScore && highScore > lowScore) return '高';
        if (mediumScore > lowScore) return '中';
        return '低';
    }

    /**
     * 部門推定
     */
    estimateDepartment(text) {
        let maxScore = 0;
        let estimatedDepartment = '全社';

        Object.keys(this.departmentKeywords).forEach(dept => {
            let score = 0;
            this.departmentKeywords[dept].forEach(keyword => {
                if (text.includes(keyword)) score += 1;
            });

            if (score > maxScore) {
                maxScore = score;
                estimatedDepartment = dept;
            }
        });

        return estimatedDepartment;
    }

    /**
     * 文章の重要度計算
     */
    calculateSentencePriority(sentence) {
        const urgentKeywords = ['緊急', '至急', '重要', 'すぐに', '即座に'];
        const score = urgentKeywords.reduce((acc, keyword) => {
            return acc + (sentence.includes(keyword) ? 1 : 0);
        }, 0);
        
        if (score >= 2) return '高';
        if (score >= 1) return '中';
        return '低';
    }

    /**
     * 結果表示
     */
    displayResults(analysis, priority, department) {
        // 推定された部門と重要度を自動設定
        const departmentSelect = document.getElementById('department');
        const prioritySelect = document.getElementById('priority');
        
        if (departmentSelect && department) {
            departmentSelect.value = department;
        }
        
        if (prioritySelect && priority) {
            prioritySelect.value = priority;
        }

        // 分析結果をUIに表示
        this.updateAnalysisUI(analysis);

        // 結果エリアを表示
        document.getElementById('analysisResults')?.classList.remove('hidden');
        document.getElementById('analysisPlaceholder')?.classList.add('hidden');

        // 成功メッセージ
        this.showAnalysisSuccess(analysis, priority, department);
    }

    /**
     * 解析結果UI更新
     */
    updateAnalysisUI(analysis) {
        // 課題
        const issuesContent = document.getElementById('issuesContent');
        if (issuesContent) {
            if (analysis.issues.length > 0) {
                issuesContent.innerHTML = analysis.issues
                    .map((item, index) => `<div class="mb-2 p-2 bg-red-50 rounded border-l-2 border-red-300">${index + 1}. ${item}</div>`)
                    .join('');
            } else {
                issuesContent.innerHTML = '<p class="text-gray-500 italic">特定の課題は検出されませんでした</p>';
            }
        }

        // 決定事項
        const decisionsContent = document.getElementById('decisionsContent');
        if (decisionsContent) {
            if (analysis.decisions.length > 0) {
                decisionsContent.innerHTML = analysis.decisions
                    .map((item, index) => `<div class="mb-2 p-2 bg-orange-50 rounded border-l-2 border-orange-300">${index + 1}. ${item}</div>`)
                    .join('');
            } else {
                decisionsContent.innerHTML = '<p class="text-gray-500 italic">決定事項は検出されませんでした</p>';
            }
        }

        // タスク・アクションアイテム
        const tasksContent = document.getElementById('tasksContent');
        if (tasksContent) {
            if (analysis.tasks.length > 0) {
                tasksContent.innerHTML = analysis.tasks
                    .map((item, index) => `<div class="mb-2 p-2 bg-green-50 rounded border-l-2 border-green-300">${index + 1}. ${item}</div>`)
                    .join('');
            } else {
                tasksContent.innerHTML = '<p class="text-gray-500 italic">アクションアイテムは検出されませんでした</p>';
            }
        }

        // 議論のポイント
        const discussionContent = document.getElementById('discussionContent');
        if (discussionContent) {
            if (analysis.discussion.length > 0) {
                discussionContent.innerHTML = analysis.discussion
                    .map((item, index) => `<div class="mb-2 p-2 bg-blue-50 rounded border-l-2 border-blue-300">${index + 1}. ${item}</div>`)
                    .join('');
            } else {
                discussionContent.innerHTML = '<p class="text-gray-500 italic">主要な議論点は検出されませんでした</p>';
            }
        }

        // 次のステップ
        const nextStepsContent = document.getElementById('nextStepsContent');
        if (nextStepsContent) {
            if (analysis.nextSteps.length > 0) {
                nextStepsContent.innerHTML = analysis.nextSteps
                    .map((item, index) => `<div class="mb-2 p-2 bg-purple-50 rounded border-l-2 border-purple-300">${index + 1}. ${item}</div>`)
                    .join('');
            } else {
                nextStepsContent.innerHTML = '<p class="text-gray-500 italic">次のステップは検出されませんでした</p>';
            }
        }
    }

    /**
     * 解析成功メッセージ
     */
    showAnalysisSuccess(analysis, priority, department) {
        const totalItems = analysis.issues.length + analysis.decisions.length + 
                          analysis.tasks.length + analysis.discussion.length + analysis.nextSteps.length;

        const notification = document.createElement('div');
        notification.className = 'fixed top-4 right-4 bg-green-500 text-white px-6 py-4 rounded-lg shadow-lg z-50 max-w-sm';
        notification.innerHTML = `
            <div class="flex items-start">
                <i class="fas fa-check-circle text-xl mr-3 mt-1"></i>
                <div>
                    <p class="font-semibold mb-1">AI解析完了</p>
                    <p class="text-sm opacity-90">
                        ${totalItems}項目を検出<br>
                        部門: ${department} | 重要度: ${priority}
                    </p>
                </div>
                <button class="ml-3 text-white hover:text-gray-200" onclick="this.parentElement.parentElement.remove()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        // 5秒後に自動削除
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 5000);
    }

    /**
     * カスタム解析パターンの追加
     * 介護事業特有のパターンを後から追加可能
     */
    addCustomPattern(category, keywords) {
        if (this.careKeywords[category]) {
            this.careKeywords[category] = [...this.careKeywords[category], ...keywords];
        } else {
            this.careKeywords[category] = keywords;
        }
        console.log(`カスタムパターン追加: ${category}`, keywords);
    }

    /**
     * 解析統計情報の取得
     */
    getAnalysisStats(text) {
        const sentences = this.splitIntoSentences(text);
        const wordCount = text.length;
        const sentenceCount = sentences.length;
        
        return {
            wordCount,
            sentenceCount,
            avgSentenceLength: Math.round(wordCount / sentenceCount),
            estimatedReadingTime: Math.ceil(wordCount / 400) // 日本語の平均読速
        };
    }
}

// グローバルインスタンス化
window.AIAnalyzer = new AIAnalyzer();

// 初期化ログ
document.addEventListener('DOMContentLoaded', () => {
    console.log('AI解析システム準備完了 - 介護事業特化モード');
});