/**
 * 議事録管理システム - メインJavaScript
 * 介護事業の経営効率化を目的とした議事録管理システム
 */

class MeetingMinutesManager {
    constructor() {
        this.currentTab = 'upload';
        this.meetings = [];
        this.init();
    }

    init() {
        this.bindEvents();
        this.loadMeetings();
        this.updateAnalytics();
    }

    bindEvents() {
        // タブ切り替え
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const tab = e.currentTarget.dataset.tab;
                this.switchTab(tab);
            });
        });

        // 検索・フィルター
        document.getElementById('searchInput')?.addEventListener('input', (e) => {
            this.filterMeetings();
        });

        document.getElementById('filterDepartment')?.addEventListener('change', () => {
            this.filterMeetings();
        });

        document.getElementById('filterPriority')?.addEventListener('change', () => {
            this.filterMeetings();
        });

        // 議事録保存
        document.getElementById('saveBtn')?.addEventListener('click', () => {
            this.saveMeetingMinutes();
        });

        // エクスポート
        document.getElementById('exportPdfBtn')?.addEventListener('click', () => {
            this.exportToPDF();
        });

        document.getElementById('exportWordBtn')?.addEventListener('click', () => {
            this.exportToWord();
        });
    }

    switchTab(tabId) {
        // タブボタンの状態更新
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('active', 'bg-blue-600', 'text-white');
            btn.classList.add('text-gray-600', 'hover:text-gray-800');
        });
        
        document.querySelector(`[data-tab="${tabId}"]`).classList.add('active', 'bg-blue-600', 'text-white');
        document.querySelector(`[data-tab="${tabId}"]`).classList.remove('text-gray-600', 'hover:text-gray-800');

        // コンテンツの表示切り替え
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });
        
        document.getElementById(tabId).classList.add('active');
        this.currentTab = tabId;

        // タブ固有の処理
        if (tabId === 'list') {
            this.renderMeetingsList();
        } else if (tabId === 'analytics') {
            this.updateAnalytics();
        }
    }

    async loadMeetings() {
        try {
            const response = await fetch('tables/meeting_minutes?limit=100&sort=created_at');
            const data = await response.json();
            this.meetings = data.data || [];
            console.log('会議データロード完了:', this.meetings.length, '件');
        } catch (error) {
            console.error('会議データの読み込みエラー:', error);
            this.meetings = [];
        }
    }

    filterMeetings() {
        const searchTerm = document.getElementById('searchInput')?.value.toLowerCase() || '';
        const departmentFilter = document.getElementById('filterDepartment')?.value || '';
        const priorityFilter = document.getElementById('filterPriority')?.value || '';

        const filteredMeetings = this.meetings.filter(meeting => {
            const matchesSearch = !searchTerm || 
                meeting.title.toLowerCase().includes(searchTerm) ||
                meeting.participants.toLowerCase().includes(searchTerm) ||
                (meeting.issues && meeting.issues.toLowerCase().includes(searchTerm));
            
            const matchesDepartment = !departmentFilter || meeting.department === departmentFilter;
            const matchesPriority = !priorityFilter || meeting.priority === priorityFilter;

            return matchesSearch && matchesDepartment && matchesPriority;
        });

        this.renderMeetingsList(filteredMeetings);
    }

    renderMeetingsList(meetings = this.meetings) {
        const listContainer = document.getElementById('meetingsList');
        
        if (!meetings.length) {
            listContainer.innerHTML = `
                <div class="text-center py-12 text-gray-500">
                    <i class="fas fa-inbox text-4xl mb-4"></i>
                    <p>該当する議事録がありません</p>
                </div>
            `;
            return;
        }

        const meetingsHtml = meetings.map(meeting => this.createMeetingCard(meeting)).join('');
        listContainer.innerHTML = `<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">${meetingsHtml}</div>`;
    }

    createMeetingCard(meeting) {
        const date = new Date(meeting.meeting_date).toLocaleDateString('ja-JP');
        const priorityColor = {
            '高': 'border-red-500 bg-red-50',
            '中': 'border-yellow-500 bg-yellow-50', 
            '低': 'border-green-500 bg-green-50'
        };

        return `
            <div class="meeting-card bg-white rounded-lg shadow-sm border-l-4 ${priorityColor[meeting.priority] || 'border-gray-300'} p-6 cursor-pointer" onclick="meetingManager.viewMeeting('${meeting.id}')">
                <div class="flex justify-between items-start mb-3">
                    <h3 class="text-lg font-semibold text-gray-900 line-clamp-2">${meeting.title}</h3>
                    <span class="text-xs px-2 py-1 bg-blue-100 text-blue-800 rounded-full">${meeting.department || '未分類'}</span>
                </div>
                
                <div class="space-y-2 text-sm text-gray-600 mb-4">
                    <div class="flex items-center">
                        <i class="fas fa-calendar-alt mr-2"></i>
                        ${date}
                    </div>
                    <div class="flex items-center">
                        <i class="fas fa-users mr-2"></i>
                        ${meeting.participants || '参加者未記録'}
                    </div>
                    <div class="flex items-center">
                        <i class="fas fa-flag mr-2"></i>
                        重要度: ${meeting.priority || '未設定'}
                    </div>
                </div>

                <div class="text-xs text-gray-500 mb-3">
                    作成者: ${meeting.created_by || '不明'} | 
                    ${meeting.status || '下書き'}
                </div>

                <div class="flex justify-between items-center">
                    <div class="flex space-x-2">
                        <button class="text-blue-600 hover:text-blue-800 text-sm" onclick="event.stopPropagation(); meetingManager.editMeeting('${meeting.id}')">
                            <i class="fas fa-edit mr-1"></i>編集
                        </button>
                        <button class="text-green-600 hover:text-green-800 text-sm" onclick="event.stopPropagation(); meetingManager.exportMeetingPDF('${meeting.id}')">
                            <i class="fas fa-file-pdf mr-1"></i>PDF
                        </button>
                    </div>
                    <span class="text-xs text-gray-400">${new Date(meeting.created_at).toLocaleDateString('ja-JP')}</span>
                </div>
            </div>
        `;
    }

    async saveMeetingMinutes() {
        const meetingData = this.collectMeetingData();
        
        if (!meetingData.title) {
            alert('議事録のタイトルを入力してください');
            return;
        }

        try {
            const response = await fetch('tables/meeting_minutes', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(meetingData)
            });

            if (response.ok) {
                const savedMeeting = await response.json();
                this.meetings.unshift(savedMeeting);
                
                // 成功メッセージ
                this.showSuccessMessage('議事録が正常に保存されました');
                
                // フォームリセット
                this.resetForm();
                
                // リストタブに切り替え
                this.switchTab('list');
            } else {
                throw new Error('保存に失敗しました');
            }
        } catch (error) {
            console.error('保存エラー:', error);
            alert('議事録の保存中にエラーが発生しました');
        }
    }

    collectMeetingData() {
        return {
            title: document.getElementById('meetingTitle')?.value || '',
            meeting_date: document.getElementById('meetingDate')?.value || new Date().toISOString(),
            participants: document.getElementById('participants')?.value || '',
            department: document.getElementById('department')?.value || '',
            priority: document.getElementById('priority')?.value || '中',
            status: '下書き',
            created_by: '代表取締役',
            original_text: document.getElementById('originalText')?.value || '',
            issues: document.getElementById('issuesContent')?.innerHTML || '',
            decisions: document.getElementById('decisionsContent')?.innerHTML || '',
            tasks: document.getElementById('tasksContent')?.innerHTML || '',
            discussion_points: document.getElementById('discussionContent')?.innerHTML || '',
            next_steps: document.getElementById('nextStepsContent')?.innerHTML || '',
            file_name: window.currentFileName || ''
        };
    }

    resetForm() {
        // フォーム要素のリセット
        document.getElementById('meetingTitle').value = '';
        document.getElementById('meetingDate').value = '';
        document.getElementById('participants').value = '';
        document.getElementById('department').value = '';
        document.getElementById('priority').value = '';
        
        // 解析結果のリセット
        document.getElementById('analysisResults')?.classList.add('hidden');
        document.getElementById('analysisPlaceholder')?.classList.remove('hidden');
        
        // アップロード状態のリセット
        document.getElementById('analyzeBtn').disabled = true;
        window.currentFileName = '';
        window.extractedText = '';
    }

    showSuccessMessage(message) {
        // 簡易的な成功メッセージ表示
        const notification = document.createElement('div');
        notification.className = 'fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-md shadow-lg z-50';
        notification.innerHTML = `<i class="fas fa-check mr-2"></i>${message}`;
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }

    async viewMeeting(meetingId) {
        const meeting = this.meetings.find(m => m.id === meetingId);
        if (!meeting) return;

        // 詳細表示用のモーダルを実装（簡略化）
        console.log('会議詳細表示:', meeting);
        alert(`会議詳細: ${meeting.title}\n\n詳細表示機能は今後のアップデートで実装予定です。`);
    }

    async editMeeting(meetingId) {
        console.log('会議編集:', meetingId);
        alert('編集機能は今後のアップデートで実装予定です。');
    }

    async exportMeetingPDF(meetingId) {
        const meeting = this.meetings.find(m => m.id === meetingId);
        if (!meeting) return;

        // PDF出力（ExportUtilsクラスを使用）
        if (window.ExportUtils) {
            window.ExportUtils.exportMeetingToPDF(meeting);
        } else {
            alert('PDF出力機能の初期化中です。しばらくお待ちください。');
        }
    }

    updateAnalytics() {
        // 統計情報の更新
        document.getElementById('totalMinutes').textContent = this.meetings.length;
        
        // 未対応課題数（簡略化）
        const openIssuesCount = this.meetings.filter(m => m.issues && m.issues.trim()).length;
        document.getElementById('openIssues').textContent = openIssuesCount;
        
        // アクションアイテム数
        const totalTasks = this.meetings.filter(m => m.tasks && m.tasks.trim()).length;
        document.getElementById('totalTasks').textContent = totalTasks;
        
        // 今月の会議数
        const thisMonth = new Date().getMonth();
        const thisYear = new Date().getFullYear();
        const monthlyCount = this.meetings.filter(m => {
            const meetingDate = new Date(m.meeting_date);
            return meetingDate.getMonth() === thisMonth && meetingDate.getFullYear() === thisYear;
        }).length;
        document.getElementById('monthlyMeetings').textContent = monthlyCount;

        // チャート更新（AnalyticsManagerが利用可能な場合）
        if (window.AnalyticsManager) {
            window.AnalyticsManager.updateCharts(this.meetings);
        }
    }

    // PDF出力（基本実装）
    exportToPDF() {
        const analysisResults = document.getElementById('analysisResults');
        if (!analysisResults || analysisResults.classList.contains('hidden')) {
            alert('出力する議事録がありません。まず議事録を解析してください。');
            return;
        }

        if (window.ExportUtils) {
            const meetingData = this.collectMeetingData();
            window.ExportUtils.exportToPDF(meetingData);
        } else {
            alert('PDF出力機能の読み込み中です。しばらくお待ちください。');
        }
    }

    // Word出力（基本実装）
    exportToWord() {
        const analysisResults = document.getElementById('analysisResults');
        if (!analysisResults || analysisResults.classList.contains('hidden')) {
            alert('出力する議事録がありません。まず議事録を解析してください。');
            return;
        }

        if (window.ExportUtils) {
            const meetingData = this.collectMeetingData();
            window.ExportUtils.exportToWord(meetingData);
        } else {
            alert('Word出力機能の読み込み中です。しばらくお待ちください。');
        }
    }
}

// グローバルインスタンス
let meetingManager;

// DOM読み込み完了時の初期化
document.addEventListener('DOMContentLoaded', () => {
    meetingManager = new MeetingMinutesManager();
    console.log('議事録管理システム初期化完了');
});

// グローバル関数（HTMLから呼び出し用）
window.meetingManager = {
    viewMeeting: (id) => meetingManager?.viewMeeting(id),
    editMeeting: (id) => meetingManager?.editMeeting(id),
    exportMeetingPDF: (id) => meetingManager?.exportMeetingPDF(id)
};