/**
 * エクスポートユーティリティ
 * PDF・Word形式での議事録出力機能
 */

class ExportUtils {
    constructor() {
        this.companyName = '介護事業会社'; // 会社名
        this.logoUrl = ''; // ロゴURL（必要に応じて設定）
        this.init();
    }

    init() {
        console.log('エクスポートユーティリティ初期化完了');
    }

    /**
     * PDF出力（jsPDF使用）
     */
    async exportToPDF(meetingData) {
        try {
            // jsPDFの初期化確認
            if (typeof window.jsPDF === 'undefined') {
                throw new Error('PDF生成ライブラリが読み込まれていません');
            }

            const { jsPDF } = window.jsPDF;
            const doc = new jsPDF({
                orientation: 'portrait',
                unit: 'mm',
                format: 'a4'
            });

            // 日本語フォント設定（基本フォントを使用）
            doc.setFont('helvetica');
            
            // 現在のページ位置
            let yPosition = 20;
            const pageWidth = 210; // A4幅
            const leftMargin = 20;
            const rightMargin = 20;
            const contentWidth = pageWidth - leftMargin - rightMargin;

            // ヘッダー部分
            yPosition = this.addPDFHeader(doc, meetingData, yPosition, leftMargin);
            
            // 基本情報
            yPosition = this.addPDFBasicInfo(doc, meetingData, yPosition, leftMargin);
            
            // 各セクション
            yPosition = this.addPDFSection(doc, '課題・問題点', meetingData.issues || '', yPosition, leftMargin, contentWidth);
            yPosition = this.addPDFSection(doc, '決定事項', meetingData.decisions || '', yPosition, leftMargin, contentWidth);
            yPosition = this.addPDFSection(doc, 'アクションアイテム', meetingData.tasks || '', yPosition, leftMargin, contentWidth);
            yPosition = this.addPDFSection(doc, '議論のポイント', meetingData.discussion_points || '', yPosition, leftMargin, contentWidth);
            yPosition = this.addPDFSection(doc, '次のステップ', meetingData.next_steps || '', yPosition, leftMargin, contentWidth);
            
            // フッター
            this.addPDFFooter(doc, meetingData);

            // ファイル名生成
            const fileName = this.generateFileName(meetingData, 'pdf');
            
            // ダウンロード
            doc.save(fileName);
            
            console.log('PDF出力完了:', fileName);
            this.showExportSuccess('PDF', fileName);
            
        } catch (error) {
            console.error('PDF出力エラー:', error);
            alert('PDF出力中にエラーが発生しました: ' + error.message);
        }
    }

    /**
     * Word出力（docx.js使用）
     */
    async exportToWord(meetingData) {
        try {
            // docx.jsの確認
            if (typeof docx === 'undefined') {
                throw new Error('Word生成ライブラリが読み込まれていません');
            }

            const { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType, BorderStyle } = docx;

            // 文書構造の作成
            const children = [];

            // タイトル
            children.push(
                new Paragraph({
                    children: [
                        new TextRun({
                            text: meetingData.title || '議事録',
                            bold: true,
                            size: 32
                        })
                    ],
                    heading: HeadingLevel.TITLE,
                    alignment: AlignmentType.CENTER
                })
            );

            // 基本情報
            children.push(
                new Paragraph({
                    children: [new TextRun({ text: '', break: 1 })]
                }),
                new Paragraph({
                    children: [
                        new TextRun({
                            text: '基本情報',
                            bold: true,
                            size: 24
                        })
                    ],
                    heading: HeadingLevel.HEADING_1
                })
            );

            // 基本情報の詳細
            const basicInfo = [
                `開催日時: ${this.formatDate(meetingData.meeting_date)}`,
                `参加者: ${meetingData.participants || '記録なし'}`,
                `担当部門: ${meetingData.department || '未設定'}`,
                `重要度: ${meetingData.priority || '未設定'}`,
                `作成者: ${meetingData.created_by || '不明'}`
            ];

            basicInfo.forEach(info => {
                children.push(
                    new Paragraph({
                        children: [new TextRun({ text: info })],
                        indent: { left: 400 }
                    })
                );
            });

            // 各セクション
            this.addWordSection(children, '課題・問題点', meetingData.issues);
            this.addWordSection(children, '決定事項', meetingData.decisions);
            this.addWordSection(children, 'アクションアイテム', meetingData.tasks);
            this.addWordSection(children, '議論のポイント', meetingData.discussion_points);
            this.addWordSection(children, '次のステップ', meetingData.next_steps);

            // フッター情報
            children.push(
                new Paragraph({
                    children: [new TextRun({ text: '', break: 2 })]
                }),
                new Paragraph({
                    children: [
                        new TextRun({
                            text: `作成日時: ${new Date().toLocaleString('ja-JP')}`,
                            italics: true,
                            size: 18
                        })
                    ],
                    alignment: AlignmentType.RIGHT
                })
            );

            // 文書作成
            const doc = new Document({
                sections: [{
                    children: children
                }]
            });

            // Blob生成とダウンロード
            const blob = await Packer.toBlob(doc);
            const fileName = this.generateFileName(meetingData, 'docx');
            
            // FileSaver.jsを使用してダウンロード
            if (typeof saveAs !== 'undefined') {
                saveAs(blob, fileName);
            } else {
                // 代替ダウンロード方法
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = fileName;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
            }
            
            console.log('Word出力完了:', fileName);
            this.showExportSuccess('Word', fileName);
            
        } catch (error) {
            console.error('Word出力エラー:', error);
            alert('Word出力中にエラーが発生しました: ' + error.message);
        }
    }

    /**
     * 既存会議のPDF出力
     */
    async exportMeetingToPDF(meeting) {
        await this.exportToPDF(meeting);
    }

    /**
     * 既存会議のWord出力  
     */
    async exportMeetingToWord(meeting) {
        await this.exportToWord(meeting);
    }

    // === PDF関連のヘルパーメソッド ===

    addPDFHeader(doc, meetingData, yPosition, leftMargin) {
        // 会社名
        doc.setFontSize(10);
        doc.text(this.companyName, leftMargin, yPosition);
        
        // タイトル
        doc.setFontSize(18);
        doc.setFont('helvetica', 'bold');
        const title = meetingData.title || 'Meeting Minutes';
        doc.text(title, leftMargin, yPosition + 15);
        
        // 線
        doc.setLineWidth(0.5);
        doc.line(leftMargin, yPosition + 20, 190, yPosition + 20);
        
        return yPosition + 30;
    }

    addPDFBasicInfo(doc, meetingData, yPosition, leftMargin) {
        doc.setFontSize(10);
        doc.setFont('helvetica', 'normal');
        
        const basicInfo = [
            `Date: ${this.formatDate(meetingData.meeting_date)}`,
            `Participants: ${meetingData.participants || 'Not recorded'}`,
            `Department: ${meetingData.department || 'Not set'}`,
            `Priority: ${meetingData.priority || 'Not set'}`,
            `Created by: ${meetingData.created_by || 'Unknown'}`
        ];

        basicInfo.forEach((info, index) => {
            doc.text(info, leftMargin, yPosition + (index * 6));
        });
        
        // 区切り線
        doc.setLineWidth(0.2);
        doc.line(leftMargin, yPosition + 35, 190, yPosition + 35);
        
        return yPosition + 45;
    }

    addPDFSection(doc, title, content, yPosition, leftMargin, contentWidth) {
        // ページ境界チェック
        if (yPosition > 250) {
            doc.addPage();
            yPosition = 20;
        }
        
        // セクションタイトル
        doc.setFontSize(12);
        doc.setFont('helvetica', 'bold');
        doc.text(title, leftMargin, yPosition);
        yPosition += 8;
        
        // コンテンツ
        doc.setFontSize(9);
        doc.setFont('helvetica', 'normal');
        
        if (content && content.trim()) {
            // HTMLタグを除去してテキスト化
            const cleanContent = this.stripHTML(content);
            const lines = doc.splitTextToSize(cleanContent, contentWidth);
            
            lines.forEach(line => {
                if (yPosition > 280) {
                    doc.addPage();
                    yPosition = 20;
                }
                doc.text(line, leftMargin, yPosition);
                yPosition += 5;
            });
        } else {
            doc.text('No content available', leftMargin, yPosition);
            yPosition += 5;
        }
        
        return yPosition + 10;
    }

    addPDFFooter(doc, meetingData) {
        const pageCount = doc.internal.getNumberOfPages();
        
        for (let i = 1; i <= pageCount; i++) {
            doc.setPage(i);
            doc.setFontSize(8);
            doc.setFont('helvetica', 'normal');
            
            // ページ番号
            doc.text(`Page ${i} of ${pageCount}`, 190, 285, { align: 'right' });
            
            // 作成日時
            if (i === pageCount) {
                doc.text(`Generated: ${new Date().toLocaleString('ja-JP')}`, 20, 285);
            }
        }
    }

    // === Word関連のヘルパーメソッド ===

    addWordSection(children, title, content) {
        // セクションタイトル
        children.push(
            new docx.Paragraph({
                children: [new docx.TextRun({ text: '', break: 1 })]
            }),
            new docx.Paragraph({
                children: [
                    new docx.TextRun({
                        text: title,
                        bold: true,
                        size: 24
                    })
                ],
                heading: docx.HeadingLevel.HEADING_2
            })
        );

        // コンテンツ
        if (content && content.trim()) {
            const cleanContent = this.stripHTML(content);
            const lines = cleanContent.split('\\n').filter(line => line.trim());
            
            if (lines.length > 0) {
                lines.forEach(line => {
                    children.push(
                        new docx.Paragraph({
                            children: [new docx.TextRun({ text: line.trim() })],
                            indent: { left: 400 }
                        })
                    );
                });
            } else {
                children.push(
                    new docx.Paragraph({
                        children: [
                            new docx.TextRun({
                                text: '内容なし',
                                italics: true
                            })
                        ],
                        indent: { left: 400 }
                    })
                );
            }
        } else {
            children.push(
                new docx.Paragraph({
                    children: [
                        new docx.TextRun({
                            text: '内容なし',
                            italics: true
                        })
                    ],
                    indent: { left: 400 }
                })
            );
        }
    }

    // === ユーティリティメソッド ===

    stripHTML(html) {
        const tmp = document.createElement('div');
        tmp.innerHTML = html;
        return tmp.textContent || tmp.innerText || '';
    }

    formatDate(dateString) {
        if (!dateString) return '未設定';
        const date = new Date(dateString);
        return date.toLocaleString('ja-JP', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    generateFileName(meetingData, extension) {
        const date = meetingData.meeting_date ? 
            new Date(meetingData.meeting_date).toISOString().split('T')[0] : 
            new Date().toISOString().split('T')[0];
        
        const title = (meetingData.title || '議事録')
            .replace(/[^a-zA-Z0-9\\u3040-\\u309F\\u30A0-\\u30FF\\u4E00-\\u9FAF\\u002D\\u002E]/g, '')
            .substring(0, 20);
        
        return `${date}_${title}.${extension}`;
    }

    showExportSuccess(format, fileName) {
        const notification = document.createElement('div');
        notification.className = 'fixed top-4 right-4 bg-blue-500 text-white px-6 py-4 rounded-lg shadow-lg z-50 max-w-sm';
        notification.innerHTML = `
            <div class="flex items-start">
                <i class="fas fa-download text-xl mr-3 mt-1"></i>
                <div>
                    <p class="font-semibold mb-1">${format}出力完了</p>
                    <p class="text-sm opacity-90">
                        ファイル名: ${fileName}<br>
                        ダウンロードフォルダを確認してください
                    </p>
                </div>
                <button class="ml-3 text-white hover:text-gray-200" onclick="this.parentElement.parentElement.remove()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 5000);
    }
}

// グローバルインスタンス
window.ExportUtils = new ExportUtils();

// 初期化完了ログ
document.addEventListener('DOMContentLoaded', () => {
    console.log('エクスポート機能準備完了');
});