/**
 * 分析・統計機能
 * Chart.jsを使用した議事録データの可視化
 */

class AnalyticsManager {
    constructor() {
        this.charts = {};
        this.init();
    }

    init() {
        // Chart.jsの初期化を待つ
        if (typeof Chart !== 'undefined') {
            this.initializeCharts();
        } else {
            // Chart.jsがロードされるまで待機
            setTimeout(() => {
                this.init();
            }, 1000);
        }
    }

    initializeCharts() {
        console.log('Analytics Manager 初期化完了');
        
        // Chart.jsのデフォルト設定
        if (typeof Chart !== 'undefined') {
            Chart.defaults.font.family = 'Inter, sans-serif';
            Chart.defaults.font.size = 12;
            Chart.defaults.color = '#374151';
        }
    }

    /**
     * チャートデータ更新
     */
    updateCharts(meetings) {
        this.createDepartmentChart(meetings);
        this.createPriorityChart(meetings);
        this.createTimelineChart(meetings);
        this.createIssuesStatusChart(meetings);
    }

    /**
     * 部門別議事録数チャート
     */
    createDepartmentChart(meetings) {
        const ctx = document.getElementById('departmentChart');
        if (!ctx) return;

        // 部門別データの集計
        const departmentData = this.aggregateByDepartment(meetings);
        
        // 既存のチャートを破棄
        if (this.charts.department) {
            this.charts.department.destroy();
        }

        this.charts.department = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: Object.keys(departmentData),
                datasets: [{
                    data: Object.values(departmentData),
                    backgroundColor: [
                        '#3B82F6', // 青
                        '#EF4444', // 赤  
                        '#10B981', // 緑
                        '#F59E0B', // 黄
                        '#8B5CF6', // 紫
                        '#6B7280'  // グレー
                    ],
                    borderWidth: 2,
                    borderColor: '#FFFFFF'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = ((context.parsed / total) * 100).toFixed(1);
                                return `${context.label}: ${context.parsed}件 (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });
    }

    /**
     * 重要度別分布チャート
     */
    createPriorityChart(meetings) {
        const ctx = document.getElementById('priorityChart');
        if (!ctx) return;

        // 重要度別データの集計
        const priorityData = this.aggregateByPriority(meetings);
        
        // 既存のチャートを破棄
        if (this.charts.priority) {
            this.charts.priority.destroy();
        }

        this.charts.priority = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: Object.keys(priorityData),
                datasets: [{
                    label: '議事録数',
                    data: Object.values(priorityData),
                    backgroundColor: [
                        '#DC2626', // 高 - 赤
                        '#D97706', // 中 - オレンジ
                        '#059669'  // 低 - 緑
                    ],
                    borderColor: [
                        '#B91C1C',
                        '#B45309', 
                        '#047857'
                    ],
                    borderWidth: 1,
                    borderRadius: 4,
                    borderSkipped: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            title: function(context) {
                                return `重要度: ${context[0].label}`;
                            },
                            label: function(context) {
                                return `議事録数: ${context.parsed.y}件`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        },
                        grid: {
                            color: '#F3F4F6'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    }

    /**
     * 月次トレンドチャート（必要に応じて）
     */
    createTimelineChart(meetings) {
        // 実装は任意 - 議事録の時系列推移
        const monthlyData = this.aggregateByMonth(meetings);
        // Chart実装は今回は省略
    }

    /**
     * 課題ステータスチャート（必要に応じて）
     */
    createIssuesStatusChart(meetings) {
        // 実装は任意 - 課題の解決状況
        // Chart実装は今回は省略
    }

    /**
     * 部門別集計
     */
    aggregateByDepartment(meetings) {
        const departments = {};
        
        meetings.forEach(meeting => {
            const dept = meeting.department || '未分類';
            departments[dept] = (departments[dept] || 0) + 1;
        });

        // データが空の場合のデフォルト
        if (Object.keys(departments).length === 0) {
            return { '未分類': 0 };
        }

        return departments;
    }

    /**
     * 重要度別集計
     */
    aggregateByPriority(meetings) {
        const priorities = { '高': 0, '中': 0, '低': 0 };
        
        meetings.forEach(meeting => {
            const priority = meeting.priority || '中';
            if (priorities.hasOwnProperty(priority)) {
                priorities[priority]++;
            }
        });

        return priorities;
    }

    /**
     * 月次集計
     */
    aggregateByMonth(meetings) {
        const monthly = {};
        const now = new Date();
        
        // 過去12ヶ月分のデータを準備
        for (let i = 11; i >= 0; i--) {
            const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
            const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
            monthly[key] = 0;
        }
        
        meetings.forEach(meeting => {
            if (meeting.meeting_date) {
                const date = new Date(meeting.meeting_date);
                const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
                if (monthly.hasOwnProperty(key)) {
                    monthly[key]++;
                }
            }
        });

        return monthly;
    }

    /**
     * 統計サマリーの計算
     */
    calculateSummaryStats(meetings) {
        return {
            totalMeetings: meetings.length,
            
            // 未対応課題数（課題があり、タスクがない会議）
            openIssues: meetings.filter(m => 
                m.issues && m.issues.trim() && (!m.tasks || !m.tasks.trim())
            ).length,
            
            // 総アクションアイテム数
            totalTasks: meetings.filter(m => 
                m.tasks && m.tasks.trim()
            ).length,
            
            // 今月の会議数
            monthlyMeetings: meetings.filter(m => {
                if (!m.meeting_date) return false;
                const meetingDate = new Date(m.meeting_date);
                const now = new Date();
                return meetingDate.getMonth() === now.getMonth() && 
                       meetingDate.getFullYear() === now.getFullYear();
            }).length,

            // 部門別統計
            departmentStats: this.aggregateByDepartment(meetings),
            
            // 重要度別統計
            priorityStats: this.aggregateByPriority(meetings),

            // 平均参加者数（推定）
            avgParticipants: this.calculateAverageParticipants(meetings)
        };
    }

    /**
     * 平均参加者数計算
     */
    calculateAverageParticipants(meetings) {
        const validMeetings = meetings.filter(m => m.participants && m.participants.trim());
        if (validMeetings.length === 0) return 0;

        const totalParticipants = validMeetings.reduce((sum, meeting) => {
            // カンマ区切りで参加者数を推定
            const count = meeting.participants.split(',').filter(p => p.trim()).length;
            return sum + count;
        }, 0);

        return Math.round(totalParticipants / validMeetings.length * 10) / 10; // 小数点1桁
    }

    /**
     * エクスポート用統計データ生成
     */
    generateReportData(meetings) {
        const stats = this.calculateSummaryStats(meetings);
        
        return {
            generatedAt: new Date().toISOString(),
            period: `${new Date().getFullYear()}年${new Date().getMonth() + 1}月時点`,
            summary: stats,
            trends: {
                monthly: this.aggregateByMonth(meetings),
                department: stats.departmentStats,
                priority: stats.priorityStats
            },
            recommendations: this.generateRecommendations(stats)
        };
    }

    /**
     * 改善提案生成（介護事業特化）
     */
    generateRecommendations(stats) {
        const recommendations = [];

        // 未対応課題が多い場合
        if (stats.openIssues > stats.totalMeetings * 0.3) {
            recommendations.push({
                type: '課題管理',
                priority: '高',
                message: '未対応課題が多数あります。アクションプランの策定と定期フォローアップの実施を推奨します。',
                action: '課題管理シートの導入'
            });
        }

        // 高重要度の議事録が多い場合
        if (stats.priorityStats['高'] > stats.totalMeetings * 0.4) {
            recommendations.push({
                type: '優先順位管理',
                priority: '中',
                message: '高重要度の案件が多く、対応リソースの分散が懸念されます。',
                action: '重要度の見直しとリソース配分の最適化'
            });
        }

        // 月次会議数が少ない場合
        if (stats.monthlyMeetings < 2) {
            recommendations.push({
                type: 'コミュニケーション',
                priority: '中', 
                message: 'コミュニケーション頻度の向上により、課題の早期発見・解決が期待できます。',
                action: '定期ミーティングの設定'
            });
        }

        // 特定部門に偏りがある場合
        const maxDeptMeetings = Math.max(...Object.values(stats.departmentStats));
        const totalMeetings = Object.values(stats.departmentStats).reduce((a, b) => a + b, 0);
        
        if (maxDeptMeetings > totalMeetings * 0.6) {
            recommendations.push({
                type: '部門連携',
                priority: '低',
                message: '特定部門の会議に偏りがあります。部門間連携の強化を検討してください。',
                action: '全社横断会議の実施'
            });
        }

        return recommendations;
    }

    /**
     * チャートのリセット
     */
    resetCharts() {
        Object.values(this.charts).forEach(chart => {
            if (chart) chart.destroy();
        });
        this.charts = {};
    }

    /**
     * ダッシュボードデータの更新
     */
    updateDashboard(meetings) {
        const stats = this.calculateSummaryStats(meetings);
        
        // 統計値の更新
        this.updateStatElement('totalMinutes', stats.totalMeetings);
        this.updateStatElement('openIssues', stats.openIssues);
        this.updateStatElement('totalTasks', stats.totalTasks);
        this.updateStatElement('monthlyMeetings', stats.monthlyMeetings);

        // チャートの更新
        this.updateCharts(meetings);
        
        console.log('ダッシュボード更新完了:', stats);
    }

    updateStatElement(elementId, value) {
        const element = document.getElementById(elementId);
        if (element) {
            // アニメーション効果
            const currentValue = parseInt(element.textContent) || 0;
            this.animateNumber(element, currentValue, value, 500);
        }
    }

    animateNumber(element, start, end, duration) {
        const startTime = performance.now();
        const difference = end - start;

        function updateNumber(currentTime) {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            
            const current = Math.round(start + (difference * progress));
            element.textContent = current;

            if (progress < 1) {
                requestAnimationFrame(updateNumber);
            }
        }

        requestAnimationFrame(updateNumber);
    }
}

// グローバルインスタンス
window.AnalyticsManager = new AnalyticsManager();

// Chart.js CDNローディング確認
document.addEventListener('DOMContentLoaded', () => {
    // Chart.jsのロードを確認
    function checkChartJS() {
        if (typeof Chart !== 'undefined') {
            console.log('Chart.js ロード確認完了');
            if (window.AnalyticsManager) {
                window.AnalyticsManager.initializeCharts();
            }
        } else {
            console.log('Chart.js を待機中...');
            setTimeout(checkChartJS, 500);
        }
    }
    
    checkChartJS();
});